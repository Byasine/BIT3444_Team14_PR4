﻿Public Class Arc
    ' Dependencies: Node

    ' Arc properties
    Public Property ID As String
    Public Property Tail As Node
    Public Property Head As Node
    Public Property Distance As Decimal
    Public Property Cost As Decimal
    Public Property Flow As Decimal

    Public Overrides Function ToString() As String
        Return ID & " : " & Cost
    End Function

End Class
