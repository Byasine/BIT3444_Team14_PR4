﻿Imports System.Data.OleDb
Public Class FrmData
    Public Property DS As DataSet
    Public Property DA As OleDbDataAdapter
    Public Property DB As Database1
    Public Property TableName As String

    Public Sub RefreshTable()
        dgvData.DataSource = DS.Tables(TableName).DefaultView
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        DB.UpdateDatabase(DA, DS, TableName)
    End Sub
End Class