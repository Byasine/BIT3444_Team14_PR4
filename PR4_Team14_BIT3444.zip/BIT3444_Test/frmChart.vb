﻿Imports System.Windows.Forms.DataVisualization.Charting
Public Class frmChart
    Public Property Net As Network

    Public Sub AddSeries(chr As Chart, sName As String,
                         pointsx As List(Of String), pointsy As List(Of Decimal),
                         chrType As SeriesChartType, xTitle As String, yTitle As String, mainTitle As String)
        chr.Series.Add(sName)
        chr.Series(sName).ChartType = chrType
        chr.Series(sName).ChartArea = "ChartArea1"

        With chr.ChartAreas("ChartArea1").AxisX
            .MinorTickMark.Enabled = True
            .Interval = 1
            .IsLabelAutoFit = True
            .LabelAutoFitStyle = LabelAutoFitStyles.DecreaseFont
            .Title = xTitle
            .LabelStyle.Angle = 90
        End With

        chr.ChartAreas("ChartArea1").AxisY.Title = yTitle

        If chr.Titles.Count < 1 Then
            chr.Titles.Add(mainTitle)
        End If

        For i As Integer = 0 To pointsx.Count - 1
            chr.Series(sName).Points.AddXY(pointsx(i), pointsy(i))
        Next

    End Sub
    Public Sub GetChartValues()
        Dim pointsx As List(Of String)
        Dim pointsy As List(Of Decimal)
        For Each x In Net.DriverSList.Values
            pointsx.Add(x.ToString)
            pointsy.Add(x.DriverRoute.RouteLength)
        Next
        Addseries(chrResults, "Title", pointsx, pointsy, SeriesChartType.Bar, "Drivers", "Total Distance", "Distance Traveled by Driver")
    End Sub
    Private Sub frmChart_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetChartValues()
    End Sub
End Class