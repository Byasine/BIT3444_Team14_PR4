﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.SolverToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SolverWindowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeliveryLocationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DriverRoutesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SolutionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MapToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WindowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.SolverWindowStripButton = New System.Windows.Forms.ToolStripButton()
        Me.DeliveryLocationStripButton = New System.Windows.Forms.ToolStripButton()
        Me.DriverRoutesStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.MapStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ChartStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutStripButton = New System.Windows.Forms.ToolStripButton()
        Me.HelpStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SolverToolStripMenuItem, Me.SolutionToolStripMenuItem, Me.WindowToolStripMenuItem, Me.InfoToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.MdiWindowListItem = Me.WindowToolStripMenuItem
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 28)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'SolverToolStripMenuItem
        '
        Me.SolverToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SolverWindowToolStripMenuItem, Me.DeliveryLocationToolStripMenuItem, Me.DriverRoutesToolStripMenuItem})
        Me.SolverToolStripMenuItem.Name = "SolverToolStripMenuItem"
        Me.SolverToolStripMenuItem.Size = New System.Drawing.Size(64, 24)
        Me.SolverToolStripMenuItem.Text = "Solver"
        Me.SolverToolStripMenuItem.ToolTipText = "Solver"
        '
        'SolverWindowToolStripMenuItem
        '
        Me.SolverWindowToolStripMenuItem.Name = "SolverWindowToolStripMenuItem"
        Me.SolverWindowToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.SolverWindowToolStripMenuItem.Text = "Solver Window"
        Me.SolverWindowToolStripMenuItem.ToolTipText = "Solver Window"
        '
        'DeliveryLocationToolStripMenuItem
        '
        Me.DeliveryLocationToolStripMenuItem.Name = "DeliveryLocationToolStripMenuItem"
        Me.DeliveryLocationToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.DeliveryLocationToolStripMenuItem.Text = "Delivery Location"
        Me.DeliveryLocationToolStripMenuItem.ToolTipText = "Delivery Location"
        '
        'DriverRoutesToolStripMenuItem
        '
        Me.DriverRoutesToolStripMenuItem.Name = "DriverRoutesToolStripMenuItem"
        Me.DriverRoutesToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.DriverRoutesToolStripMenuItem.Text = "Driver Routes"
        Me.DriverRoutesToolStripMenuItem.ToolTipText = "Driver Routes"
        '
        'SolutionToolStripMenuItem
        '
        Me.SolutionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MapToolStripMenuItem, Me.ChartToolStripMenuItem})
        Me.SolutionToolStripMenuItem.Name = "SolutionToolStripMenuItem"
        Me.SolutionToolStripMenuItem.Size = New System.Drawing.Size(78, 24)
        Me.SolutionToolStripMenuItem.Text = "Solution"
        Me.SolutionToolStripMenuItem.ToolTipText = "Solution"
        '
        'MapToolStripMenuItem
        '
        Me.MapToolStripMenuItem.Name = "MapToolStripMenuItem"
        Me.MapToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.MapToolStripMenuItem.Text = "Map"
        Me.MapToolStripMenuItem.ToolTipText = "Map"
        '
        'ChartToolStripMenuItem
        '
        Me.ChartToolStripMenuItem.Name = "ChartToolStripMenuItem"
        Me.ChartToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.ChartToolStripMenuItem.Text = "Chart"
        Me.ChartToolStripMenuItem.ToolTipText = "Chart"
        '
        'WindowToolStripMenuItem
        '
        Me.WindowToolStripMenuItem.Name = "WindowToolStripMenuItem"
        Me.WindowToolStripMenuItem.Size = New System.Drawing.Size(78, 24)
        Me.WindowToolStripMenuItem.Text = "Window"
        Me.WindowToolStripMenuItem.ToolTipText = "Current Windows"
        '
        'InfoToolStripMenuItem
        '
        Me.InfoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.InfoToolStripMenuItem.Name = "InfoToolStripMenuItem"
        Me.InfoToolStripMenuItem.Size = New System.Drawing.Size(49, 24)
        Me.InfoToolStripMenuItem.Text = "Info"
        Me.InfoToolStripMenuItem.ToolTipText = "Info"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.AboutToolStripMenuItem.Text = "About"
        Me.AboutToolStripMenuItem.ToolTipText = "About"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.HelpToolStripMenuItem.Text = "Help"
        Me.HelpToolStripMenuItem.ToolTipText = "Help"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(35, 35)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SolverWindowStripButton, Me.DeliveryLocationStripButton, Me.DriverRoutesStripButton, Me.ToolStripSeparator1, Me.MapStripButton, Me.ChartStripButton, Me.ToolStripSeparator2, Me.AboutStripButton, Me.HelpStripButton})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 28)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(800, 62)
        Me.ToolStrip1.TabIndex = 3
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'SolverWindowStripButton
        '
        Me.SolverWindowStripButton.Image = Global.Solver2.My.Resources.Resources.NetworkWin
        Me.SolverWindowStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SolverWindowStripButton.Name = "SolverWindowStripButton"
        Me.SolverWindowStripButton.Size = New System.Drawing.Size(113, 59)
        Me.SolverWindowStripButton.Text = "Solver Window"
        Me.SolverWindowStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.SolverWindowStripButton.ToolTipText = "Solver Window"
        '
        'DeliveryLocationStripButton
        '
        Me.DeliveryLocationStripButton.Image = Global.Solver2.My.Resources.Resources.DeliveryLocation
        Me.DeliveryLocationStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DeliveryLocationStripButton.Name = "DeliveryLocationStripButton"
        Me.DeliveryLocationStripButton.Size = New System.Drawing.Size(128, 59)
        Me.DeliveryLocationStripButton.Text = "Delivery Location"
        Me.DeliveryLocationStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'DriverRoutesStripButton
        '
        Me.DriverRoutesStripButton.Image = Global.Solver2.My.Resources.Resources.AllPairsSP
        Me.DriverRoutesStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.DriverRoutesStripButton.Name = "DriverRoutesStripButton"
        Me.DriverRoutesStripButton.Size = New System.Drawing.Size(102, 59)
        Me.DriverRoutesStripButton.Text = "Driver Routes"
        Me.DriverRoutesStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 62)
        '
        'MapStripButton
        '
        Me.MapStripButton.Image = Global.Solver2.My.Resources.Resources.map
        Me.MapStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.MapStripButton.Name = "MapStripButton"
        Me.MapStripButton.Size = New System.Drawing.Size(43, 59)
        Me.MapStripButton.Text = "Map"
        Me.MapStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ChartStripButton
        '
        Me.ChartStripButton.Image = Global.Solver2.My.Resources.Resources.chart
        Me.ChartStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ChartStripButton.Name = "ChartStripButton"
        Me.ChartStripButton.Size = New System.Drawing.Size(48, 59)
        Me.ChartStripButton.Text = "Chart"
        Me.ChartStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 62)
        '
        'AboutStripButton
        '
        Me.AboutStripButton.Image = Global.Solver2.My.Resources.Resources.Users
        Me.AboutStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AboutStripButton.Name = "AboutStripButton"
        Me.AboutStripButton.Size = New System.Drawing.Size(54, 59)
        Me.AboutStripButton.Text = "About"
        Me.AboutStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'HelpStripButton
        '
        Me.HelpStripButton.Image = Global.Solver2.My.Resources.Resources.Help
        Me.HelpStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpStripButton.Name = "HelpStripButton"
        Me.HelpStripButton.Size = New System.Drawing.Size(45, 59)
        Me.HelpStripButton.Text = "Help"
        Me.HelpStripButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMain"
        Me.Text = "Main"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents SolverToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SolverWindowToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeliveryLocationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DriverRoutesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SolutionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MapToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ChartToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WindowToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents InfoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents SolverWindowStripButton As ToolStripButton
    Friend WithEvents DeliveryLocationStripButton As ToolStripButton
    Friend WithEvents DriverRoutesStripButton As ToolStripButton
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents MapStripButton As ToolStripButton
    Friend WithEvents ChartStripButton As ToolStripButton
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents AboutStripButton As ToolStripButton
    Friend WithEvents HelpStripButton As ToolStripButton
    Friend WithEvents ToolTip1 As ToolTip
End Class
