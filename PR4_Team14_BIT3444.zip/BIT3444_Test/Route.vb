﻿Public Class Route
    Public Property RouteList As List(Of String)
    Public Property RouteLength As Decimal
    Public Property RouteDetail As SortedList(Of String, List(Of Arc))

End Class
