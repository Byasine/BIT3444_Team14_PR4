﻿Public Class frmLogin
    Public Property MainForm As frmMain
    Dim userData As New Database1(True)

    ' gets username and password from user, checks them against the users in the database
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try
            If Not userData.UserFound(txtUsername.Text, txtPassword.Text) Then
                Throw New Exception("Username/Password not found.")
            Else
                Me.Hide()
                MainForm = New frmMain
                MainForm.ShowDialog()
                Dim result As Integer = MessageBox.Show("Are you sure you want to exit Network Solver?", "Exit Network Solver", MessageBoxButtons.YesNoCancel)
                If result = DialogResult.Yes Then
                    Application.Exit()
                Else
                    txtPassword.Text = ""
                    Me.Show()
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Login error")
        End Try
    End Sub

    ' checks if the user wants to exit the application
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Dim result As Integer = MessageBox.Show("Are you sure you want to exit Network Solver?", "Exit Network Solver", MessageBoxButtons.YesNoCancel)
        If result = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub
End Class