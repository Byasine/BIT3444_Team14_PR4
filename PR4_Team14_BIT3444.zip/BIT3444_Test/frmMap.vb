﻿Public Class frmMap
    Public Property MapImage As Image = My.Resources.WhiteBackground
    Public Property Net As Network
    Private Property Xscale As Decimal
    Private Property Yscale As Decimal
    Private Property Count As Integer = 0
    Public Function FindDriverByName2() As Driver

        If cboDriver3.SelectedIndex = -1 Then
            Return Nothing
        End If

        Dim FDN = From i In Net.DriverSList.Values
                  Where cboDriver3.Text = i.Last & ", " & i.First
        Return FDN(0)

    End Function
    Public Sub ShowRouteDetail(e As PaintEventArgs)

        For Each n In Net.NodeSList.Values
            DrawNode(n, Color.Black, Color.White, Color.Black, e)
        Next

        For Each a In Net.ArcSList.Values
            DrawArc(a, Color.Gray, 4, True, e)
        Next

        Dim rtDriver As Driver = FindDriverByName2()
        If rtDriver Is Nothing Then
            Exit Sub
        End If
        If rtDriver.DriverRoute Is Nothing Then
            Exit Sub
        End If
        If rtDriver.DriverRoute.RouteList Is Nothing Then
            Exit Sub
        End If

        Dim nRouteList As List(Of String) = rtDriver.DriverRoute.RouteList
        For i = 0 To nRouteList.Count - 2
            Dim legVar As String = nRouteList(i) & “-TO-“ & nRouteList(i + 1)
            Dim aList As List(Of Arc) = rtDriver.DriverRoute.RouteDetail(legVar)
            Dim aLength As Decimal
            For Each a In aList
                DrawArc(a, Color.Gray, 4, True, e)
                DrawNode(a.Head, Color.Black, Color.White, Color.Black, e)
                aLength += a.Cost
            Next
        Next
        For Each x In rtDriver.DriverRoute.RouteList
            Dim nodeV = Net.NodeSList(x)
            DrawNode(nodeV, Color.Green, Color.Green, Color.Black, e)
        Next

    End Sub

    ' Draws a node with given border, fill and text format 
    Public Sub DrawNode(n As Node, borderColor As Color, fillColor As Color,
                        textColor As Color, e As PaintEventArgs)

        ' offsetting the center of the node to be the coordinates of the node
        Dim size As Decimal = 30 * Math.Min(Xscale, Yscale)
        Dim x As Integer = Xscale * n.XCoord - size / 2
        Dim y As Integer = Yscale * n.YCoord - size / 2

        ' creating the borders and the fill for the node
        Dim fillBrush As New SolidBrush(fillColor)
        e.Graphics.FillEllipse(fillBrush, x, y, size, size)
        Dim borderPen As New Pen(borderColor)
        borderPen.Width = 2
        e.Graphics.DrawEllipse(borderPen, x, y, size, size)

        ' setting font properties of the text
        Dim fontSize As Integer = size / 3
        Dim aFont As New System.Drawing.Font("Courier New", fontSize, FontStyle.Bold)

        ' offsetting the center of text to match the middle of node
        Dim textwidth As Integer = Text.Count * (fontSize)
        Dim tx As Integer = Xscale * n.XCoord - textwidth / 2
        Dim ty As Integer = Yscale * n.YCoord - aFont.GetHeight() / 2

        ' creating text
        Dim textBrush As New SolidBrush(textColor)
        e.Graphics.DrawString(n.ID, aFont, textBrush, tx, ty)

    End Sub

    ' Draws an arc with given color, width, and direction 
    Public Sub DrawArc(a As Arc, arcColor As Color, arcWidth As Integer,
                       directed As Boolean, e As PaintEventArgs)

        ' setting properties of pen to draw arcs
        Dim arcPen As New Pen(arcColor)
        arcPen.Width = arcWidth
        arcPen.StartCap = Drawing2D.LineCap.Round 'RoundAnchor
        If directed Then
            'arcPen.EndCap = Drawing2D.LineCap.ArrowAnchor
            arcPen.CustomEndCap = New Drawing2D.AdjustableArrowCap(1.5 * arcWidth,
                                                                   1.5 * arcWidth)
        Else
            arcPen.EndCap = Drawing2D.LineCap.Round 'RoundAnchor
        End If

        ' draw arc
        e.Graphics.DrawLine(arcPen, Xscale * a.Tail.XCoord, Yscale * a.Tail.YCoord,
                                    Xscale * a.Head.XCoord, Yscale * a.Head.YCoord)

    End Sub
    ' event handler for painting Panel2, where the map is drawn with respect to the problem type
    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint
        ShowRouteDetail(e)
    End Sub
    ' refresh panel when combo boxes change
    Private Sub cboDriver3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDriver3.SelectedIndexChanged
        Panel2.Refresh()
    End Sub
End Class