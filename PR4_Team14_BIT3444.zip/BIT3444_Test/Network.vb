﻿Public Class Network
    ' Node and arc lists
    Public Property NodeSList As New SortedList(Of String, Node)
    Public Property ArcSList As New SortedList(Of String, Arc)
    Public Property DriverSList As SortedList(Of String, Driver)
    Public Property LocationDriverSList As New SortedList(Of String, Driver)

    ' signals when there is a change in network
    Public Event NetworkChanged(net As Network)

    ' default constructor
    Public Sub New()

    End Sub
End Class
