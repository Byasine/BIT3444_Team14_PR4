﻿Imports System.Data.OleDb
Public Class frmDashboard

    ' declare properties
    Public Property DB As Database1
    Public Property Net As New Network
    Public Property Opt As New Optimization
    Public Property DatabasePath As String
    Public Property MainForm As frmMain
    Public Property newMap As frmMap
    Public Property newChart As frmChart

    ' builds network with respect to a given radius
    Public Sub FindDriverCenterNode(driver As Driver)

        Dim mindist As Decimal = 1000
        Dim centNode As Node = Nothing
        For Each x In Net.NodeSList.Values
            Dim curdist As Decimal = Math.Sqrt((x.XCoord - driver.XCoord) ^ (2) + (x.YCoord - driver.YCoord) ^ (2))
            If curdist < mindist Then
                mindist = curdist
                centNode = x
            End If
        Next
        driver.CenterNode = centNode

    End Sub

    Public Sub BuildDriverLocationList(drv As Driver)

        Dim DeliveryList = From Location In Net.NodeSList.Values
                           Where Location.Delivery = 1
        For Each Delivery In DeliveryList
            Dim distance As Decimal
            Opt.ShortestPath(Net, drv.CenterNode.ID, Delivery.ID, distance)
            drv.LocationSList.Add(Delivery.ID, distance)
        Next

    End Sub

    Public Sub Initialize()

        DB = New Database1(DatabasePath)
        Net.NodeSList = DB.GetNodes()
        Net.ArcSList = DB.GetArcs(Net.NodeSList)
        Net.DriverSList = DB.GetDriver()

        ' section 4.1
        For Each s In Net.NodeSList.Values
            If s.Delivery = 1 Then
                Net.LocationDriverSList.Add(s.ID, Nothing)
            End If
        Next

        lstData.Items.Clear()

        For Each v In DB.MyDataSet.Tables
            lstData.Items.Add(v.TableName)
        Next
        lstData.SelectedIndex = 0
        For Each a In Net.DriverSList.Values
            FindDriverCenterNode(a)
            BuildDriverLocationList(a)
        Next
        For Each i In Net.DriverSList.Values
            cboDrivers.Items.Add(i.First & ", " & i.Last)
        Next
        cboDrivers.SelectedIndex = 0

        cboDrivers2.Items.Clear()
        For Each j In Net.DriverSList.Values
            Dim str As String = j.Last & ", " & j.First
            cboDrivers2.Items.Add(str)
        Next
        cboDrivers2.SelectedIndex = 0

    End Sub
    Public Function FindDriverByName() As Driver

        ' section 4.2
        If cboDrivers.SelectedIndex = -1 Then
            Return Nothing
        End If

        Dim FDN = From i In Net.DriverSList.Values
                  Where cboDrivers.Text = i.First & ", " & i.Last
        Return FDN(0)

    End Function

    ' finds the average distance from the center Node of the selected driver in the cboDriver
    ' in that driver's DeliveryList
    Public Sub CalculateAverageDistance()
        If lstDelivery.Items.Count = 0 Then
            txtAverageDistance.Text = 0
        Else
            Dim totDistance As Double
            Dim driverName As Driver = FindDriverByName()
            For Each i In lstDelivery.Items
                totDistance += driverName.LocationSList(i) ' see here to decide between .values or .sList
            Next
            Dim averageDist = totDistance / lstDelivery.Items.Count
            txtAverageDistance.Text = FormatNumber(averageDist, 2)
        End If
    End Sub

    Public Sub PopulateLocations(inputD As Driver)

        ' section 4.3 
        If inputD Is Nothing Then
            Exit Sub
        End If


        lstLocation.Items.Clear()

        For Each key In inputD.LocationSList.Keys
            If Not inputD.DeliveryList.Contains(key) And
                Net.LocationDriverSList(key) Is Nothing Then
                lstLocation.Items.Add(key)

            End If
        Next
        lstLocation.Sorted = True
        lstDelivery.Items.Clear()
        For Each id In inputD.DeliveryList
            lstDelivery.Items.Add(id)
        Next
        CalculateAverageDistance()

    End Sub

    Public Sub AddLocationToDeliveryList()

        Try
            If lstLocation.Items.Count() = 0 Then
                Throw New Exception("No location to add.")
            ElseIf lstLocation.SelectedIndex < 0 Then
                Throw New Exception("Please select a location to add.")
            End If
            Dim locationText As String = lstLocation.Text
            lstDelivery.Items.Add(locationText)
            lstDelivery.Sorted = True
            lstLocation.Items.Remove(locationText)
            CalculateAverageDistance()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Input Error")
        End Try

    End Sub

    ' moves a selected location from lstDelivery back to lstLocation
    Public Sub RemoveLocationFromDeliveryList()

        Try
            If lstDelivery.Items.Count() = 0 Then
                Throw New Exception("No location to remove.")
            ElseIf lstDelivery.SelectedIndex < 0 Then
                Throw New Exception("Please select a location to remove.")
            End If
            Dim deliveryText As String = lstDelivery.Text
            lstLocation.Items.Add(deliveryText)
            lstLocation.Sorted = True
            lstDelivery.Items.Remove(deliveryText)
            CalculateAverageDistance()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Input Error")
        End Try

    End Sub

    ' updates the DeliveryList property of the driver selected in cboDriver with the items in lstDelivery
    Public Sub SaveDeliveryLocations()
        ' section 4.5
        Dim deliveryDriver As Driver = FindDriverByName()
        deliveryDriver.DeliveryList.Clear()
        For Each i In lstDelivery.Items
            deliveryDriver.DeliveryList.Add(i)
            Net.LocationDriverSList(i) = deliveryDriver
        Next
        With deliveryDriver
            .DeliveryList.Sort()
            .RouteList.Clear()
            .DriverRoute = Nothing
        End With
        For Each it In lstLocation.Items
            Net.LocationDriverSList(it) = Nothing
        Next
        cboDrivers2.SelectedIndex = -1
        cboDrivers2.SelectedIndex = cboDrivers.SelectedIndex
        MessageBox.Show("Delivery list of " & cboDrivers.SelectedItem.ToString() & " has been saved.")

    End Sub

    ' uses an OpenFileDialog to let the user chose the database to be used, enables group box controls, and calls Initialize
    Public Sub OpenDatabase()

        Dim openDlg As New OpenFileDialog
        openDlg.Filter = "accdb files (*.accdb)|*.accdb|All files (*.*)|*.*"
        If openDlg.ShowDialog() = DialogResult.OK Then
            DatabasePath = openDlg.FileName
            txtDatabasePath.Text = DatabasePath ' allowing user to choose a database to work with
            gbxDataTables.Enabled = True
            gbxDeliveryLocations.Enabled = True
            Initialize()
            gbxRoutes.Enabled = True ' before or after Initialize
        End If

    End Sub

    ' shows the table chosen in lstData in a DataGridView object
    Public Sub OpenTable()

        Try
            Dim dataForm As New FrmData
            Dim tableName As String = lstData.Text
            dataForm.TableName = tableName
            dataForm.Text = tableName
            dataForm.DS = DB.MyDataSet
            dataForm.DB = DB
            Select Case tableName
                Case "Nodes"
                    dataForm.DA = DB.NodesDA
                Case "Arcs"
                    dataForm.DA = DB.ArcsDA
                Case "Drivers"
                    dataForm.DA = DB.DriversDA
                Case Else
                    Throw New Exception("Select a table first.")
            End Select
            With dataForm
                .RefreshTable()
                .Show()
                .BringToFront()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Table Error")
        End Try

    End Sub

    ' section 5.1
    Public Sub AssignAllDeliveryLocations()
        Dim response = MessageBox.Show("This action will overwrite previous delivery locations. Would you like to continue?", "Overwrite Warning", MessageBoxButtons.YesNo)
        If response = DialogResult.No Then
            Exit Sub
        Else
            Opt.AssignDeliveryLocations(Net)
            cboDrivers.SelectedIndex = -1
            cboDrivers.SelectedIndex = 0
            cboDrivers2.SelectedIndex = -1
            cboDrivers2.SelectedIndex = cboDrivers.SelectedIndex
        End If
    End Sub

    ' section 5.2
    Public Function FindDriverByName2() As Driver

        If cboDrivers2.SelectedIndex = -1 Then
            Return Nothing
        End If

        Dim FDN = From i In Net.DriverSList.Values
                  Where cboDrivers2.Text = i.Last & ", " & i.First
        Return FDN(0)

    End Function

    ' section 5.3
    Public Function MakeRouteList() As List(Of String)
        If lstRoute.Items.Count = 0 Then
            Return Nothing
        End If
        Dim routeList As New List(Of String)
        routeList.Add("0")
        For Each i In lstRoute.Items
            routeList.Add(i)
        Next
        routeList.Add("0")
        Return routeList
    End Function

    ' section 5.4
    Public Function GetRouteDetail(routeList As List(Of String), ByRef length As Decimal) As SortedList(Of String, List(Of Arc))
        If routeList Is Nothing Then
            Return Nothing
        End If
        Dim arcList As New SortedList(Of String, List(Of Arc))
        For i = 0 To routeList.Count - 2
            Dim currLength As Decimal
            Dim path As List(Of Arc)
            path = Opt.ShortestPath(Net, routeList(i), routeList(i + 1), currLength)
            Dim routeKey As String = routeList(i) & “-TO-“ & routeList(i + 1)
            arcList.Add(routeKey, path)
            length += currLength
        Next
        Return arcList
    End Function

    ' section 5.5
    Public Function CreateRoute() As Route
        Dim newRoute As New Route
        newRoute.RouteList = MakeRouteList()
        newRoute.RouteDetail = GetRouteDetail(newRoute.RouteList, newRoute.RouteLength)
        Return newRoute
    End Function

    ' section 5.6
    Public Sub SaveRoute()
        Dim drvr As Driver = FindDriverByName2()
        drvr.RouteList.Clear()
        For Each i In lstRoute.Items
            drvr.RouteList.Add(i)
        Next
        drvr.DriverRoute = CreateRoute()
        MessageBox.Show("Driver " & cboDrivers2.Text & " has been saved.")
    End Sub

    ' section 5.7 
    Public Sub ShowRouteDetail()
        trvRouteDetail.Nodes.Clear()
        Dim rtDriver As Driver = FindDriverByName2()
        If rtDriver Is Nothing Then
            Exit Sub
        End If
        If rtDriver.DriverRoute Is Nothing Then
            Exit Sub
        End If
        If rtDriver.DriverRoute.RouteList Is Nothing Then
            Exit Sub
        End If
        Dim nRouteList As List(Of String) = rtDriver.DriverRoute.RouteList
        For i = 0 To nRouteList.Count - 2
            Dim currTreeNode As New TreeNode
            Dim legVar As String = nRouteList(i) & “-TO-“ & nRouteList(i + 1)
            Dim aList As List(Of Arc) = rtDriver.DriverRoute.RouteDetail(legVar)
            Dim aLength As Decimal
            For Each a In aList
                Dim newTn As New TreeNode
                newTn.Text = a.ToString
                currTreeNode.Nodes.Add(newTn) ' Add the new tree node variable to the nodes collection of the current tree node variable
                aLength += a.Cost
            Next
            currTreeNode.Text = legVar & ": " & aLength
            trvRouteDetail.Nodes.Add(currTreeNode)
        Next

    End Sub

    ' section 5.8
    Public Sub Populatelocations2(drvr As Driver)
        If drvr Is Nothing Then
            Exit Sub
        End If
        lstlocation2.Items.Clear()
        For Each x In drvr.DeliveryList
            If Not drvr.RouteList.Contains(x) Then
                lstlocation2.Items.Add(x)
            End If
        Next
        lstlocation2.Sorted = True
        lstRoute.Items.Clear()
        For Each a In drvr.RouteList
            lstRoute.Items.Add(a)
        Next
        Dim cRoute As Route = CreateRoute()
        txtRouteLength.Text = cRoute.RouteLength
        ShowRouteDetail()
    End Sub

    ' section 5.9
    Public Sub AddLocationToRouteList()
        Try
            If lstlocation2.Items.Count = 0 Then
                Throw New Exception("There is nothing to add")
            End If
            If lstlocation2.SelectedIndex < 0 Then
                Throw New Exception("Select a location to add")
            End If
            Dim strg As String = lstlocation2.Text
            lstRoute.Items.Add(strg)
            lstlocation2.Items.Remove(strg)
            Dim rRoute As Route = CreateRoute()
            rRoute.RouteLength = txtRouteLength.Text
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error")
        End Try
    End Sub

    ' section 5.10
    Public Sub RemoveLocationFromRouteList()
        Try
            If lstRoute.Items.Count = 0 Then
                Throw New Exception("There is nothing to remove")
            End If
            If lstRoute.SelectedIndex < 0 Then
                Throw New Exception("Select a location to remove")
            End If
            Dim stg As String = lstRoute.Text
            lstlocation2.Items.Add(stg)
            lstlocation2.Sorted = True
            lstRoute.Items.Remove(stg)
            Dim rtRoute As Route = CreateRoute()
            rtRoute.RouteLength = txtRouteLength.Text
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error")
        End Try
    End Sub

    ' section 5.11 ' walk through with Dr. Seref
    Public Sub AddNextLocationToRoute()
        Try
            If lstlocation2.Items.Count = 0 Then
                Throw New Exception("There is nothing to add")
            End If
            Dim currLoc As String
            If lstRoute.Items.Count = 0 Then
                currLoc = "0"
            End If
            currLoc = lstRoute.Items.Count - 1
            Dim minDist = 1000000000
            Dim minLoc As String = ""
            For Each i In lstlocation2.Items
                Dim mLength As Decimal
                Opt.ShortestPath(Net, currLoc, i, mLength)
                If mLength < minDist Then
                    minDist = mLength
                    minLoc = i
                End If
            Next
            Dim indexVar As Integer = lstlocation2.Items.IndexOf(minLoc)
            lstlocation2.SelectedIndex = indexVar
            AddLocationToRouteList()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error")
        End Try
    End Sub

    ' section 5.12
    Public Sub AddAllLocationsToRoute()
        Do While lstlocation2.Items.Count > 0
            AddNextLocationToRoute()
        Loop
    End Sub

    ' event handlers
    Private Sub frmDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        gbxDataTables.Enabled = False
        gbxDeliveryLocations.Enabled = False
        gbxRoutes.Enabled = False
    End Sub

    Private Sub btnOpenDatabase_Click(sender As Object, e As EventArgs) Handles btnOpenDatabase.Click
        OpenDatabase()
    End Sub

    Private Sub btnOpenTable_Click(sender As Object, e As EventArgs) Handles btnOpenTable.Click
        OpenTable()
    End Sub

    Private Sub cboDrivers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDrivers.SelectedIndexChanged
        Dim dataDriver As Driver = FindDriverByName()
        PopulateLocations(dataDriver)
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        AddLocationToDeliveryList()
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        RemoveLocationFromDeliveryList()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        SaveDeliveryLocations()
    End Sub

    Private Sub btnAssignAll_Click(sender As Object, e As EventArgs) Handles btnAssignAll.Click
        AssignAllDeliveryLocations()
    End Sub

    Private Sub cboDrivers2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDrivers2.SelectedIndexChanged
        Dim dataDriver2 As Driver = FindDriverByName2()
        Populatelocations2(dataDriver2)
    End Sub

    Private Sub btnAdd2_Click(sender As Object, e As EventArgs) Handles btnAdd2.Click
        AddLocationToRouteList()
    End Sub

    Private Sub btnRemove2_Click(sender As Object, e As EventArgs) Handles btnRemove2.Click
        RemoveLocationFromRouteList()
    End Sub

    Private Sub btnSave2_Click(sender As Object, e As EventArgs) Handles btnSave2.Click
        SaveRoute()
        Dim dtDriver As Driver = FindDriverByName2()
        Populatelocations2(dtDriver)
    End Sub

    Private Sub btnAssignAll2_Click(sender As Object, e As EventArgs) Handles btnAssignAll2.Click
        AddAllLocationsToRoute()
    End Sub
End Class
